/*
 * Created on Feb 25, 2006
 *
 */
package org.openqa.selenium.server.htmlrunner;

public interface HTMLResultsListener {
    public void processResults(HTMLTestResults results);
}
